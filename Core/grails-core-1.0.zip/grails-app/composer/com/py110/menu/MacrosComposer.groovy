package com.py110.menu

import org.zkoss.zkgrails.GrailsComposer

class MacrosComposer extends GrailsComposer {

    def afterCompose = { window ->
        // initialize components here
    }
}
