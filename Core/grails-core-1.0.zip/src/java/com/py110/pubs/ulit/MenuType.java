package com.py110.pubs.ulit;

/**
 * 菜单类型
 */
public class MenuType {
    public static final String MURL = "url";
    public static final String MCLAZZ = "clazz";
    public static final String MNONE = "none";
}
