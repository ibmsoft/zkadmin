package com.py110.pubs.ulit;

import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2010-11-2
 * Time: 17:37:22
 * To change this template use File | Settings | File Templates.
 */
public  class SysConfig {
    final Map configMap;

    public SysConfig(Map configMap) {
        this.configMap = configMap;
    }
    
}
